function GO_for_RECDG
clear all; clc;  close all; warning ('off','all');
addpath(genpath(pwd));
popsize=30; maxit=500; 
NumOfRuns=20;
global mpopt
mpopt = mpoption('pf.alg', 'NR');
global EXPload np nq
EXPload=1;
np=0.0; nq=0;
Tai='Com';
switch Tai
    case 'Ind'
        np=0.18; nq=6; % Tai cong nghiep
    case 'Res'
        np=0.92; nq=4.04; % Tai dan dung
    case 'Com'
        np=1.51; nq=3.4; % Tai thuong mai
    case 'Con'
        np=0.0; nq=0; % Cong suat khong doi
    case 'Mix'
        global sc1 sc2 sc3
        sc1=0.4; sc2=0.3; sc3=0.3; %trong so [CN DD TM]
        np=[0.18 0.92 1.51];
        nq=[6 4.04 3.4];
end
busdata = xlsread('data33.xls','dulieubus');
line= xlsread('data33.xls','dulieuline');
Ub=[10 7 15 21 11 33 33 33 2 2 2];
Lb=[1 1 1 1 1 2 2 2  0 0 0];
nd=11;
ff = 'fobj';
popsize=popsize; dimension=nd; xmax=Ub; xmin=Lb;
tic;
for test_no=1:NumOfRuns
    clc; disp(['GO, run no. ', num2str(test_no)]);
    FEs=0;P1=5;P2=0.001;P3=0.3;
    MaxFEs=popsize*2*maxit;
    up_matrix=repmat(xmax,popsize,1);
    dow_matrix=repmat(xmin,popsize,1);
    x=dow_matrix+(up_matrix-dow_matrix).*rand(popsize,dimension);
    gbestfitness=inf;
    for i=1:popsize
        x(i,:)= fix_switches(x(i,:),Ub, Lb);
        fitness(i)= feval(ff,x(i,:),busdata,line);
        FEs=FEs+1;
        if gbestfitness>fitness(i)
            gbestfitness=fitness(i);
            gbestX=x(i,:);
        end
        gbesthistory(FEs)=gbestfitness;
    end
    iter=0;clear globalbest;
    while FEs<=MaxFEs
        iter=iter+1;
        [~, ind]=sort(fitness);
        Best_X=x(ind(1),:);
        for i=1:popsize
            Worst_X = x(ind(randi([popsize-P1+1,popsize],1)),:);
            Better_X=x(ind(randi([2,P1],1)),:);
            random=selectID(popsize,i,2);
            L1=random(1);
            L2=random(2);
            Gap1=(Best_X-Better_X);
            Gap2=(Best_X-Worst_X);
            Gap3=(Better_X-Worst_X);
            Gap4=(x(L1,:)-x(L2,:));
            Distance1=norm(Gap1);
            Distance2=norm(Gap2);
            Distance3=norm(Gap3);
            Distance4=norm(Gap4);
            SumDistance=Distance1+Distance2+Distance3+Distance4;
            if SumDistance==0
                SumDistance=1e-10;
            end
            LF1=Distance1/SumDistance;
            LF2=Distance2/SumDistance;
            LF3=Distance3/SumDistance;
            LF4=Distance4/SumDistance;
            SF=fitness(i)/max(fitness);
            KA1=LF1*SF*Gap1; KA2=LF2*SF*Gap2; KA3=LF3*SF*Gap3; KA4=LF4*SF*Gap4;
            newx(i,:)=x(i,:)+KA1+KA2+KA3+KA4;
            newx(i,:)= fix_switches(newx(i,:),Ub, Lb);
            newfitness= feval(ff,newx(i,:),busdata,line);
            FEs=FEs+1;
            % Real time update
            if fitness(i)>newfitness
                fitness(i)=newfitness;
                x(i,:)=newx(i,:);
            else
                if rand<P2&&ind(i)~=ind(1)
                    fitness(i)=newfitness;
                    x(i,:)=newx(i,:);
                end
            end
            if gbestfitness>fitness(i)
                gbestfitness=fitness(i);
                gbestX=x(i,:);
            end
            gbesthistory(FEs)=gbestfitness;

        end
        for i=1:popsize
            newx(i,:)=x(i,:);
            j=1;
            while j<=dimension
                if rand<P3
                    R=x(ind(randi(P1)),:);
                    newx(i,j) = x(i,j)+(R(:,j)-x(i,j))*unifrnd(0,1);
                    AF=(0.01+(0.1-0.01)*(1-FEs/MaxFEs));
                    if rand<AF
                        newx(i,j)=xmin(j)+(xmax(j)-xmin(j))*unifrnd(0,1);
                    end
                end
                j=j+1;
            end
            newx(i,:)= fix_switches(newx(i,:),Ub, Lb);
            newfitness= feval(ff,newx(i,:),busdata,line);
            FEs=FEs+1;
            if fitness(i)>newfitness
                fitness(i)=newfitness;
                x(i,:)=newx(i,:);
            else
                if rand<P2&&ind(i)~=ind(1)
                    fitness(i)=newfitness;
                    x(i,:)=newx(i,:);
                end
            end
            if gbestfitness>fitness(i)
                gbestfitness=fitness(i);
                gbestX=x(i,:);
            end
            gbesthistory(FEs)=gbestfitness;

        end
        nfe(iter)=FEs;
        BestF= gbestfitness;
        globalbest(iter)=BestF;
        BestX=gbestX;
        bestnest=BestX;
    end
    [tam,miniter]=min(globalbest);
    SW_SOP(test_no,:)= BestX;
    sumFit(test_no)=BestF;
    summinIter(test_no)=miniter;
    stop_iter=length(globalbest);
    global_F(test_no,1:stop_iter)=globalbest;
    global_F(test_no,stop_iter:maxit)=globalbest(stop_iter);
end
time_stop = toc;
[minsumFit,local]=min(sumFit);
bestSW=SW_SOP(local,:);
bestIter=summinIter(local);
disp(['FitGO =[' num2str(sumFit),']']);
disp(['popsize = ' num2str(popsize)]);
disp(['generations = ' num2str(maxit)]);
disp(['Best solution of min Fit: ', num2str(bestSW)]);
disp(['Best Fit: ', num2str(minsumFit)]);
time_to_run=(time_stop)/NumOfRuns;
disp(['Time to run:',num2str(time_to_run)]);
u = bestSW;
disp('---------------------------------------------')
swl=5;
sw=decode_switch(u(1,1:swl));
u(1,1:swl)=sw;
disp(['Loai tai: ',Tai]);
disp(['EXPload = ', num2str(EXPload), '; [np, nq] = [', num2str([np, nq]),']']);
disp(['Best SWDG: ', num2str(u)]);
optimal_system=powerflow_load_models_RECDG(u,busdata,line)
function [r]=selectID(popsize,i,k)
if k<= popsize
    vecc=[1:i-1,i+1:popsize];
    r=zeros(1,k);
    for kkk =1:k
        n = popsize-kkk;
        t = randi(n,1,1);
        r(kkk) = vecc(t);
        vecc(t)=[];
    end
end
function s=simplebounds(s,Lb,Ub)
[m,~]=size(s);
ns_tmp=s;
I=ns_tmp<Lb;
ns_tmp(I)=Lb(I);
J=ns_tmp>Ub;
ns_tmp(J)=Ub(J);
s=ns_tmp;
s=round(ns_tmp);
function y = fobj(x,busdata,linedata)
[m,n]=size(x);
for i=1:m
    [F]=RECDG_fitness(x(i,:),busdata, linedata);
    fitness(i)=F.obj';
end
y=fitness';
function X_fixed= fix_switches(X,up,dow)
[N,dim]=size(X);
up=[10 7 15 21 11 33 33 33 2 2 2];
dow=[1 1 1 1 1 2 2 2  0 0 0];
up_matrix=repmat(up,N,1);
dow_matrix=repmat(dow,N,1);
X2=X(:,9:11);
X1=round(X(:,1:8));
X=[X1,X2];
Xup=X<=up_matrix;
X=up_matrix.*not(Xup)+X.*Xup;
Xdow=X>=dow_matrix;
X=dow_matrix.*not(Xdow)+X.*Xdow;
X_fixed=X;

