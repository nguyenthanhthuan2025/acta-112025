function Sbusd=load_models_Thuan(Sbusd,Vm)
global np nq
if length(np)==1
    Sbusd=real(Sbusd).*Vm.^np+1j*imag(Sbusd).*Vm.^nq;
else     
    global sc1 sc2 sc3
    Sbusd1=sc1*(real(Sbusd).*Vm.^np(1)+1j*imag(Sbusd).*Vm.^nq(1));
    Sbusd2=sc2*(real(Sbusd).*Vm.^np(2)+1j*imag(Sbusd).*Vm.^nq(2));
    Sbusd3=sc3*(real(Sbusd).*Vm.^np(3)+1j*imag(Sbusd).*Vm.^nq(3));
    Sbusd=Sbusd1+Sbusd2+Sbusd3;
end

