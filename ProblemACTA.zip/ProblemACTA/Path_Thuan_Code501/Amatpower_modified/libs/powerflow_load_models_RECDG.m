function network = powerflow_load_models_RECDG(X1,busdata,line)
x=X1(:,1:5); 
DG=X1(:,6:8); 
SizeDG=X1(:,9:11); 
baseV=12.66;
mpc.version = '2';
mpc.baseMVA = 100;
mpc.bus=busdata;
mpc.gen = [
    1	0	0	0	0	1	100	1	0	0	0	0	0	0	0	0	0	0	0	0	0];
mpc.gen=repmat(mpc.gen,4,1); 
mpc.gen(2,1)=DG(1); mpc.gen(2,2)=SizeDG(1);
mpc.gen(3,1)=DG(2); mpc.gen(3,2)=SizeDG(2);
mpc.gen(4,1)=DG(3); mpc.gen(4,2)=SizeDG(3);
define_constants;
osw=x;
t1=length(osw);
for t1=1:t1
    t2=find(line(:,14)==osw(t1));
    line(t2,BR_STATUS)=0;
end
mpc.branch = line;
global mpopt
results=runpf(mpc,mpopt);
results.gen;
results.bus;
results.branch;
network.PP_PBCS = mpopt.pf.alg;
network.bus=results.bus;
network.gen=results.gen;
network.success=results.success;
network.Load_P=sum(results.bus(:,3));
network.Load_Q=sum(results.bus(:,4));
network.Generator_P=sum(results.gen(:,2));
network.Generator_Q=sum(results.gen(:,3));
network.Volt_profile = results.bus(:,8)';
[network.Vmin,network.busVmin]=min(network.Volt_profile);
[network.Vmax,network.busVmax]=max(network.Volt_profile);
network.Ploss=sum(results.branch(:,14)+results.branch(:,16))*1e3;
network.Qloss=sum(results.branch(:,15)+results.branch(:,17))*1e3;
network.Ploss_branch=(results.branch(:,14)+results.branch(:,16))*1e3;
network.Qloss_branch=(results.branch(:,15)+results.branch(:,17))*1e3;
network.Current=abs(get_currents(mpc.baseMVA, baseV, results.bus, results.branch));
Idm=line(:,16);
KI=network.Current./Idm; KI=KI';
network.LBI=var(KI);
network.Imax=max(KI);
network.KI=KI;
function [Current] = get_currents(baseMVA, baseV, bus, branch)
if isstruct(baseMVA)
    mpc = baseMVA;
    [baseMVA, bus, branch] = deal(mpc.baseMVA, mpc.bus, mpc.branch);
end
[PQ, PV, REF, NONE, BUS_I, BUS_TYPE, PD, QD, GS, BS, BUS_AREA, VM, ...
    VA, BASE_KV, ZONE, VMAX, VMIN, LAM_P, LAM_Q, MU_VMAX, MU_VMIN] = idx_bus;
[F_BUS, T_BUS, BR_R, BR_X, BR_B, RATE_A, RATE_B, RATE_C, ...
    TAP, SHIFT, BR_STATUS, PF, QF, PT, QT, MU_SF, MU_ST, ...
    ANGMIN, ANGMAX, MU_ANGMIN, MU_ANGMAX] = idx_brch;
i2e = bus(:, BUS_I);
e2i = sparse(max(i2e), 1);
e2i(i2e) = (1:size(bus, 1))';
out = find(branch(:, BR_STATUS) == 0);
nb = size(bus, 1);
nl = size(branch, 1);
V = bus(:, VM) .* exp(1j * pi/180 * bus(:, VA));
Cf = sparse(1:nl, e2i(branch(:, F_BUS)), branch(:, BR_STATUS), nl, nb);
Ct = sparse(1:nl, e2i(branch(:, T_BUS)), branch(:, BR_STATUS), nl, nb);
tap = ones(nl, 1);
xfmr = find(branch(:, TAP));
tap(xfmr) = branch(xfmr, TAP);
tap = tap .* exp(1j*pi/180 * branch(:, SHIFT));
A = spdiags(1 ./ tap, 0, nl, nl) * Cf - Ct;
Ysc = 1 ./ (branch(:, BR_R) - 1j * branch(:, BR_X));
Vdrop = A * V;
loss = baseMVA * Ysc .* Vdrop .* conj(Vdrop);
baseA=baseMVA*1e3/(baseV*sqrt(3));
Current=baseA * Ysc .* Vdrop;







