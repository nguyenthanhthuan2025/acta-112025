function delta1=delta_PQgrid(Generator_P, Generator_Q)
        PQgrid=[Generator_P Generator_Q]*1e3; %doi ra kW
        TH=PQgrid<0;
        PQgrid_am=TH.*PQgrid;
        delta1=sum(abs(PQgrid_am))*1e3;