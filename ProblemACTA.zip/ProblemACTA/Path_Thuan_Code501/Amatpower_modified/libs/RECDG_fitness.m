function [fit]=RECDG_fitness(u,busdata,line)
u_sw=u(:,1:5);
sw=decode_switch(u_sw);
num_sw=length(sw);
u(:,1:num_sw)=sw; 
kq= detA(sw,busdata,line); 
if (kq==1)|| (kq==-1)
    network=powerflow_load_models_RECDG(u,busdata, line);
    delta = Penalty_VI_Profile(network.Volt_profile, network.KI); 
    delta1=delta_PQgrid(network.Generator_P, network.Generator_Q);
    if network.success==1
        fit.obj=network.Ploss+delta+delta1;
    else
        fit.obj=1e9;
    end
else
    fit.obj=1e9;
end