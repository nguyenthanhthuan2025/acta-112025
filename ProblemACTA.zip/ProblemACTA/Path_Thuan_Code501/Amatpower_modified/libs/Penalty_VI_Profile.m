function delta=Penalty_VI_Profile(Volt_profile, I_profile)
Zg=0;
lamg=[1e3 1e3];
[g,geq]=constraints(Volt_profile, I_profile);
for k=1:length(g)
    H=heso(g(k));
   Zg=Zg+lamg(k)*g(k)*H;
end
delta= Zg;
if delta < 0, delta = 0;  end

function H=heso(g)
if g==0
    H=0;
else
    H=1;
end
function [g, geq]=constraints(Volt_profile, I_profile)
Vmaxcp=1.05; Vmincp=0.95; rateI_Imax=1;
tam1=Volt_profile-Vmaxcp;
tam2=Vmincp-Volt_profile;
tam3=max(tam1,0);
tam4=max(tam2,0);
tam5=sum(tam3)+sum(tam4);
g(1)=tam5;
tam6=I_profile-rateI_Imax;
tam7=max(tam6,0);
tam8=sum(tam7);
g(2)=tam8;
geq=[];
