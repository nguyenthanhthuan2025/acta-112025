function [kq]= detA(sw,busdata,line)
data_system.bus=busdata;
data_system.branch=line;
[num_node, temp]=size(data_system.bus);
[num_branch, temp]=size(data_system.branch);
for i=1:length(sw)
    data_system.branch(sw(i),11)=0;
end
A0=zeros(num_branch,num_node);
for i=1:num_branch
    A0(i,data_system.branch(i,1))=1; 
    A0(i,data_system.branch(i,2))= -1; 
end
A=A0(:,2:num_node);
size(A);
b=find(data_system.branch(:,11)~=0);
A1=A(b,:);  
[m,n]=size(A1);
if m==n
    kq=det(A1);
else
    kq=0; 
end


