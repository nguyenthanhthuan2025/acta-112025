function  CGA_for_RECDG
clear all; clc;  close all; warning ('off','all');
addpath(genpath(pwd));
popsize=60; maxit=500; 
NumOfRuns=20;
global mpopt
mpopt = mpoption('pf.alg', 'NR');
global EXPload np nq
EXPload=1;
np=0.0; nq=0;
Tai='Mix';
switch Tai
    case 'Ind'
        np=0.18; nq=6; % Tai cong nghiep
    case 'Res'
        np=0.92; nq=4.04; % Tai dan dung
    case 'Com'
        np=1.51; nq=3.4; % Tai thuong mai
    case 'Con'
        np=0.0; nq=0; % Cong suat khong doi
    case 'Mix'
        global sc1 sc2 sc3
        sc1=0.4; sc2=0.3; sc3=0.3; %trong so [CN DD TM]
        np=[0.18 0.92 1.51];
        nq=[6 4.04 3.4];
end
busdata = xlsread('data33.xls','dulieubus');
line= xlsread('data33.xls','dulieuline');
Ub=[10 7 15 21 11 33 33 33 2 2 2];
Lb=[1 1 1 1 1 2 2 2  0 0 0];
nd=11;
ff = 'fobj';
popsize=popsize; npar=nd; up=Ub; dow=Lb;
tic;
for test_no = 1:NumOfRuns
    clc; disp(['GA, run no. ', num2str(test_no)]);
    mincost=-9999999;
    mutrate=.2;
    selection=0.5;
    Nt=npar;
    keep=floor(selection*popsize);
    nmut = ceil((popsize-1)*Nt*mutrate);
    M=ceil((popsize-keep)/2);
    clear globalbest;
    clear minc;
    iter=0;
    up_matrix=repmat(up,popsize,1);
    dow_matrix=repmat(dow,popsize,1);
    par=dow_matrix+(up_matrix-dow_matrix).*rand(popsize,nd);
    par= fix_switches(par,up, dow);
    [cost]=feval(ff,par,busdata,line);
    [cost,ind]=sort(cost);
    par=par(ind,:);
    minc(1)=min(cost);
    meanc(1)=mean(cost);
    fmin=min(cost);
    while iter < maxit
        iter=iter+1;
        M=ceil((popsize-keep)/2);
        prob=flipud([1:keep]'/sum([1:keep]));
        odds=[0 cumsum(prob(1:keep))'];
        pick1=rand(1,M);
        pick2=rand(1,M);
        ic=1;
        while ic<=M
            for id=2:keep+1
                if pick1(ic)<=odds(id) & pick1(ic)>odds(id-1)
                    ma(ic)=id-1;
                end
                if pick2(ic)<=odds(id) & pick2(ic)>odds(id-1)
                    pa(ic)=id-1;
                end
            end
            ic=ic+1;
        end
        ix=1:2:keep;
        xp=ceil(rand(1,M)*Nt);
        r=rand(1,M);
        for ic=1:M
            xy=par(ma(ic),xp(ic))-par(pa(ic),xp(ic));
            par(keep+ix(ic),:)=par(ma(ic),:);
            par(keep+ix(ic)+1,:)=par(pa(ic),:);
            par(keep+ix(ic),xp(ic))=par(ma(ic),xp(ic))-r(ic).*xy;
            par(keep+ix(ic)+1,xp(ic))=par(pa(ic),xp(ic))+r(ic).*xy;
            if xp(ic)<npar
                par(keep+ix(ic),:)=[par(keep+ix(ic),1:xp(ic)),par(keep+ix(ic)+1,xp(ic)+1:npar)];
                par(keep+ix(ic)+1,:)=[par(keep+ix(ic)+1,1:xp(ic)),par(keep+ix(ic),xp(ic)+1:npar)];
            end
        end
        mrow=sort(ceil(rand(1,nmut)*(popsize-1))+1);
        mcol=ceil(rand(1,nmut)*Nt);
        up_matrix=repmat(up,popsize,1);
        dow_matrix=repmat(dow,popsize,1);
        for ii=1:nmut
            par(mrow(ii),mcol(ii))=(up_matrix(mrow(ii),mcol(ii))-dow_matrix(mrow(ii),mcol(ii)))*rand+dow_matrix(mrow(ii),mcol(ii));
        end
        par= fix_switches(par,up, dow);
        [cost]=feval(ff,par,busdata,line);
        [cost,ind]=sort(cost);
        par=par(ind,:);
        minc(iter+1)=min(cost);
        meanc(iter+1)=mean(cost);
        if iter>maxit | cost(1)<mincost
            break
        end
        globalbest=minc;
        BestF= cost(1);
        globalbest(iter)=BestF;
        BestX=par(1,:);
        bestnest=BestX;
    end
    [tam,miniter]=min(globalbest);
    SW_SOP(test_no,:)= BestX;
    sumFit(test_no)=BestF;
    summinIter(test_no)=miniter;
    stop_iter=length(globalbest);
    global_F(test_no,1:stop_iter)=globalbest;
    global_F(test_no,stop_iter:maxit)=globalbest(stop_iter);
end
time_stop = toc;
[minsumFit,local]=min(sumFit);
bestSW=SW_SOP(local,:);
disp(['FitGA =[' num2str(sumFit),']']);
disp(['popsize = ' num2str(popsize)]);
disp(['generations = ' num2str(maxit)]);
disp(['Best solution of min Fit: ', num2str(bestSW)]);
disp(['Best Fit: ', num2str(minsumFit)]);
time_to_run=(time_stop)/NumOfRuns;
disp(['Time to run:',num2str(time_to_run)]);
u = bestSW;
disp('---------------------------------------------')
swl=5;
sw=decode_switch(u(1,1:swl));
u(1,1:swl)=sw;
disp(['Load type: ',Tai]);
disp(['EXPload = ', num2str(EXPload), '; [np, nq] = [', num2str([np, nq]),']']);
disp(['Best SWDG: ', num2str(u)]);
optimal_system=powerflow_load_models_RECDG(u,busdata,line)
function [f]=fobj(x,busdata,linedata)
[m,n]=size(x);
for i=1:m
    [F]=RECDG_fitness(x(i,:),busdata, linedata);
    fitness(i)=F.obj;
end
f=fitness';
function X_fixed= fix_switches(X,up,dow)
[N,dim]=size(X);
up=[10 7 15 21 11 33 33 33 2 2 2];
dow=[1 1 1 1 1 2 2 2  0 0 0];
up_matrix=repmat(up,N,1);
dow_matrix=repmat(dow,N,1);
X2=X(:,9:11);
X1=round(X(:,1:8));
X=[X1,X2];
Xup=X<=up_matrix;
X=up_matrix.*not(Xup)+X.*Xup;
Xdow=X>=dow_matrix;
X=dow_matrix.*not(Xdow)+X.*Xdow;
X_fixed=X;
